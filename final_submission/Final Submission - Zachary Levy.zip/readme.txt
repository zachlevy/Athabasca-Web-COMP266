Different versions of the site based on Unit
	http://student.athabascau.ca/~zacharyle/


My GitHub with all the source code, all files, etc.
	https://github.com/zachlevy/Athabasca-Web-COMP266


Final zipped version of the site
	"zachary_levy_website_unit7_20140928.zip"

Zipped versions for each unit can be found on my GitHub and the Landing. Note that some functions on the site won't work locally, namely the Copy Source function.
	https://landing.athabascau.ca/file/view/664920/zachary-levy-unit-2-website-zip
	https://landing.athabascau.ca/file/view/665238/unit-3-css-website-zachary-levy
	https://landing.athabascau.ca/file/view/666317/unit-4-website-zachary-levy
	https://landing.athabascau.ca/file/view/682449/website-unit-5-zachary-levy
	https://landing.athabascau.ca/file/view/702155/unit-6-code-zachary-levy
	https://landing.athabascau.ca/file/view/712312/unit-7-website-zachary-levy


Learning Outcomes Mapped
	"Learning Outcomes Mapped - Zachary Levy.pdf"


Learning Diaries / Reflections
	"All Units Reflection - Zachary Levy.pdf"

Can be found individually in each unit folder on my GitHub and the Landing
	https://landing.athabascau.ca/file/view/508631/unit-1-reflection-zachary-levy
	https://landing.athabascau.ca/file/view/664922/unit-2-reflection-zachary-levy
	https://landing.athabascau.ca/file/view/665386/unit-3-reflection-zachary-levy
	https://landing.athabascau.ca/file/view/666022/unit-4-reflection-zachary-levy
	https://landing.athabascau.ca/file/view/668148/unit-5-reflection-zachary-levy
	https://landing.athabascau.ca/file/view/711980/unit-6-reflection-zachary-levy
	https://landing.athabascau.ca/file/view/712146/unit-7-reflection-zachary-levy


Supporting Evidence
	https://landing.athabascau.ca/blog/view/508365/what-is-the-best-software-for-css
	https://landing.athabascau.ca/blog/view/712976/my-experience-with-this-course
	https://github.com/zachlevy/Athabasca-Web-COMP266

